import { NgModule } from '@angular/core';

import { COneComponent } from './c-one.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
    imports: [SharedModule],
    declarations: [COneComponent],
    exports: [COneComponent]
})
export class MOneModule { }
