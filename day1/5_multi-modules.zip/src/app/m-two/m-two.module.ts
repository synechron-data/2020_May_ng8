import { NgModule } from '@angular/core';

import { CTwoComponent } from './c-two.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
    imports: [SharedModule],
    declarations: [CTwoComponent],
    exports: [CTwoComponent]
})
export class MTwoModule { }
