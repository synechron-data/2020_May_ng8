import { NgModule } from '@angular/core';
import { SharedComponent } from './s-com.component';

@NgModule({
    exports: [SharedComponent],
    declarations: [SharedComponent]
})
export class SharedModule { }
