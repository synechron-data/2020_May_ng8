// // 1. Element Inline Style
// import { Component, OnInit } from '@angular/core';

// @Component({
//     selector: 'c-one',
//     template: `
//         <h1 class="text-info">Hello from Component One</h1>
//         <h2 class="text-info" style="border-style:solid;border-width:2px;border-color:blue;">From Component One</h2>
//     `
// })

// export class COneComponent implements OnInit {
//     constructor() { }

//     ngOnInit() { }
// }

// // 2. Template Inline Style
// import { Component, OnInit, ViewEncapsulation } from '@angular/core';

// @Component({
//     selector: 'c-one',
//     template: `
//         <style>
//             .card {
//                 border-style: solid;
//                 border-width: 2px;
//                 border-color: blue;
//             }
//         </style>
//         <h1 class="text-info">Hello from Component One</h1>
//         <h2 class="card">From Component One</h2>
//     `,
//     encapsulation: ViewEncapsulation.Emulated
// })

// export class COneComponent implements OnInit {
//     constructor() { }

//     ngOnInit() { }
// }

// // 3. Component Inline Style
// import { Component, OnInit } from '@angular/core';

// @Component({
//     selector: 'c-one',
//     styles: [`
//         .card {
//             border-style: solid;
//             border-width: 2px;
//             border-color: blue;
//         }
//     `],
//     template: `
//         <h1 class="text-info">Hello from Component One</h1>
//         <h2 class="card">From Component One</h2>
//     `
// })

// export class COneComponent implements OnInit {
//     constructor() { }

//     ngOnInit() { }
// }

// 4. External CSS
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'c-one',
    styleUrls: ['./c-one.component.css'.toString()],
    template: `
        <h1 class="text-info">Hello from Component One</h1>
        <h2 class="card1">From Component One</h2>
    `
})

export class COneComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}