// // 1. Element Inline Style
// import { Component, OnInit } from '@angular/core';

// @Component({
//     selector: 'c-two',
//     template: `
//         <h1 class="text-success">Hello from Component Two</h1>
//         <h2 class="text-success" style="border-style:dashed;border-width:2px;border-color:green;">From Component Two</h2>
//     `
// })

// export class CTwoComponent implements OnInit {
//     constructor() { }

//     ngOnInit() { }
// }

// // 2. Template Inline Style
// import { Component, OnInit, ViewEncapsulation } from '@angular/core';

// @Component({
//     selector: 'c-two',
//     template: `
//         <style>
//             .card {
//                 border-style: dashed;
//                 border-width: 2px;
//                 border-color: green;
//             }
//         </style>
//         <h1 class="text-success">Hello from Component Two</h1>
//         <h2 class="card">From Component Two</h2>
//     `,
//     encapsulation: ViewEncapsulation.Emulated
// })

// export class CTwoComponent implements OnInit {
//     constructor() { }

//     ngOnInit() { }
// }

// // 3. Component Inline Style
// import { Component, OnInit } from '@angular/core';

// @Component({
//     selector: 'c-two',
//     styles: [`
//         .card {
//             border-style: dashed;
//             border-width: 2px;
//             border-color: green;
//         }
//     `],
//     template: `
//         <h1 class="text-success">Hello from Component Two</h1>
//         <h2 class="card">From Component Two</h2>
//     `
// })

// export class CTwoComponent implements OnInit {
//     constructor() { }

//     ngOnInit() { }
// }

// 4. External CSS
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'c-two',
    styleUrls: ['./c-two.component.css'.toString()],
    template: `
        <h1 class="text-success">Hello from Component Two</h1>
        <h2 class="card2">From Component Two</h2>
    `
})

export class CTwoComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}