import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'c-two',
    styleUrls: ['./c-two.component.css'],
    template: `
        <h1 class="text-success">Hello from Component Two</h1>
        <h2 class="card">From Component Two</h2>
    `
})

export class CTwoComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}