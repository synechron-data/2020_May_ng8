import '@angular/core';
import '@angular/common';
import '@angular/compiler';
import '@angular/platform-browser';
import '@angular/platform-browser-dynamic';

import 'rxjs';

// All other vendor files, like jQuery, Bootstrap
import 'jquery';
import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';