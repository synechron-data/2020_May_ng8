import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'assign-one',
    templateUrl: 'assign-one.component.html'
})

export class AssignOneComponent implements OnInit {
    terms: string;
    constructor() {
        this.terms = "Accept Terms";
    }

    ngOnInit() { }
}