import { Directive, ElementRef, Renderer2, HostListener, Input } from '@angular/core';

@Directive({
    selector: '[highlight]'
})
export class HighlightDirective {
    constructor(private element: ElementRef<HTMLElement>, private renderer: Renderer2) { }

    // @Input() highlightColor: string;
    @Input("highlight") highlightColor: string;

    @HostListener('mouseenter')
    onMouseEnter() {
        this.renderer.setStyle(this.element.nativeElement, "background-color", this.highlightColor);
    }

    @HostListener('mouseleave')
    onMouseLeave() {
        this.renderer.removeStyle(this.element.nativeElement, "background-color");
    }
}
// -----------------------------------------------------------------------------------

// import { Directive, ElementRef, Renderer2, HostListener } from '@angular/core';

// @Directive({
//     selector: '[highlight]'
// })
// export class HighlightDirective {
//     constructor(private element: ElementRef<HTMLElement>, private renderer: Renderer2) { }

//     @HostListener('mouseenter')
//     onMouseEnter() {
//         this.renderer.setStyle(this.element.nativeElement, "background-color", "yellow");
//     }

//     @HostListener('mouseleave')
//     onMouseLeave() {
//         this.renderer.removeStyle(this.element.nativeElement, "background-color");
//     }
// }

// ---------------------------------------------------------------------------------------

// import { Directive, ElementRef, Renderer2, OnInit } from '@angular/core';

// @Directive({
//     selector: '[highlight]'
// })
// export class HighlightDirective implements OnInit {
//     constructor(private element: ElementRef<HTMLElement>, private renderer: Renderer2) { }

//     ngOnInit(): void {
//         this.element.nativeElement.addEventListener("mouseenter", () => {
//             this.renderer.setStyle(this.element.nativeElement, "background-color", "yellow");
//         });

//         this.element.nativeElement.addEventListener("mouseleave", () => {
//             this.renderer.removeStyle(this.element.nativeElement, "background-color");
//         });
//     }
// }