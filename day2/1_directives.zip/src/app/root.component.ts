import { Component } from '@angular/core';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Directives</h1>
            </div>

            <div [hidden]="flag">
                <h2>Custom Directives</h2>
                <h3 change-content></h3>
                <list></list>
            </div>

            <div [hidden]="!flag">
                <h2>Structural Directives</h2>
                
                <list></list>

                <h3 [style.display]="name?'block':'none'">
                    Hi, {{name}}
                </h3>

                <ng-template [ngIf]="name">
                    <h3>
                        Hi, {{name}}
                    </h3>
                </ng-template>

                <h3 *ngIf="name">
                    Hi, {{name}}
                </h3>
            </div>

            <div [hidden]="!flag">
                <h2>Attribute Directives</h2>
                <h4 [ngStyle]="myStyles">
                    Style Binding
                </h4>
                <assign-two></assign-two>
            </div>
        </div>
    `
})

export class RootComponent {
    myStyles = {
        'background-color': 'green',
        'font-size': '20px',
        'color': 'white'
    };

    name: string;

    constructor() {
        // this.name = "Synechron";
    }
}