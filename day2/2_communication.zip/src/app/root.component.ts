import { Component, ViewChild, QueryList, ViewChildren } from '@angular/core';
import { CounterComponent } from './counter/counter.component';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Sharing Data between Parent and Child Component</h1>
            </div>

            <div [hidden]=!flag>
                <list [personList]=pList>
                    <h2 class="text-info">Employee List</h2>
                </list>
            </div> 

            <div [hidden]=!flag>
                <counter></counter>
                <br/>
                <counter [interval]=5></counter>
            </div>

            <div [hidden]=!flag>
                <counter #c1></counter>
                <counter #c2></counter>
                <br/>
                <div class="row">
                    <div class="col-md-2">
                        <button class="btn btn-warning btn-block" (click)="c1.reset()">Parent Reset 1</button>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-warning btn-block" (click)="p_reset(c1)">Parent Reset 2</button>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-warning btn-block" (click)="p_reset3()">Parent Reset 3</button>
                    </div>
                </div>
            </div>

            <div [hidden]=flag>
                <h3 class="alert alert-danger" *ngIf=message>{{message}}</h3>
                <counter #c1 (onMax)="updateMessage($event)" [interval]="5"></counter>
                <br/>
                <div class="row">
                    <div class="col-md-2">
                        <button class="btn btn-warning btn-block" (click)="c1.reset()">Parent Reset</button>
                    </div>
                </div>
            </div>
        </div>
    `
})

export class RootComponent {
    @ViewChild("c1", { static: true })
    counter1: CounterComponent;

    @ViewChild("c2", { static: true })
    counter2: CounterComponent;

    @ViewChildren(CounterComponent)
    counters: QueryList<CounterComponent>;

    pList: Array<string>;
    message: string;

    constructor() {
        this.pList = ["Manish", "Abhijeet", "Abhishek", "Ramakant", "Subodh"];
        this.message = "";
    }

    p_reset(c: CounterComponent) {
        c.reset();
    }

    p_reset3() {
        // this.counter1.reset();
        // this.counter2.reset();

        for (const counter of this.counters.toArray()) {
            counter.reset();
        }
    }

    updateMessage(flag: boolean) {
        if (flag)
            this.message = "Max Click Reached, please reset to continue...";
        else
            this.message = "";
    }
}