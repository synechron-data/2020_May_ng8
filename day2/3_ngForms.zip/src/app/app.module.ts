import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { RootComponent } from "./root.component";
import { TemplatedFormComponent } from "./templated-form/templated-form.component";
import { ReactiveFormComponent } from "./reactive-form/reactive-form.component";
import { ValidationFormComponent } from "./validation/validation-form.component";
import { RestrictInputDirective } from "./directives/restrict-input.directive";
import { DynamicFormComponent } from "./dynamic-form/dynamic-form.component";

@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule],
    declarations: [RootComponent, TemplatedFormComponent, ReactiveFormComponent, ValidationFormComponent,
        RestrictInputDirective, DynamicFormComponent],
    bootstrap: [RootComponent],
    providers: [
        {
            provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
                return (component: ComponentRef<any>) => {
                    console.log(component);
                }
            }
        }
    ]
})
export class AppModule {

}
