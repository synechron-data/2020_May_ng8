import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({ 
    selector: '[restrict-input]' 
})
export class RestrictInputDirective {
    constructor(private element: ElementRef<HTMLElement>) { }

    @HostListener('input', ['$event'])
    inputValidator(e: any) {
        const pattern = /^[a-zA-Z]*$/;
        if (!pattern.test(e.target.value)) {
            e.target.value = e.target.value.replace(/[^a-zA-Z]/g, "");
        }
    }
}