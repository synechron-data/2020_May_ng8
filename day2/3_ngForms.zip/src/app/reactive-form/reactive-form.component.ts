import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
    selector: 'reactive-form',
    templateUrl: 'reactive-form.component.html'
})

export class ReactiveFormComponent implements OnInit {
    regForm: FormGroup;

    constructor(private frmBuilder: FormBuilder) { }

    ngOnInit() {
        this.regForm = this.frmBuilder.group({
            firstname: "",
            lastname: "",
            address: this.frmBuilder.group({
                city: "",
                zip: 0
            })
        });
    }

    logForm() {
        // Code to send the data to API
        console.log(this.regForm.value);
    }
}

// -----------------------------------------------------------

// import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormControl } from '@angular/forms';

// @Component({
//     selector: 'reactive-form',
//     templateUrl: 'reactive-form.component.html'
// })

// export class ReactiveFormComponent implements OnInit {
//     regForm: FormGroup;

//     constructor() { }

//     ngOnInit() {
//         this.regForm = new FormGroup({
//             firstname: new FormControl(),
//             lastname: new FormControl(),
//             address: new FormGroup({
//                 city: new FormControl(),
//                 zip: new FormControl()
//             })
//         });
//     }

//     logForm() {
//         // Code to send the data to API
//         console.log(this.regForm.value);
//     }
// }