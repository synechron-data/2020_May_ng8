import { Component } from '@angular/core';
import { person } from './model/person.model';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Angular Forms</h1>
            </div>

            <!-- <templated-form></templated-form> --> 
            <!-- <reactive-form></reactive-form> -->
            <!-- <validation-form></validation-form> -->
            <dynamic-form [data]=person></dynamic-form>
        </div>
    `
})

export class RootComponent {
    person: any;

    constructor() {
        this.person = person;
    }
}