import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";

import { RootComponent } from "./root.component";
import { ListComponent } from "./list/list.component";
import { CaptionPipe } from "./pipes/caption.pipe";
import { FilterPipe } from "./pipes/filter.pipe";

@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [RootComponent, ListComponent, CaptionPipe, FilterPipe],
    bootstrap: [RootComponent],
    providers: [
        {
            provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
                return (component: ComponentRef<any>) => {
                    console.log(component);
                }
            }
        }
    ]
})
export class AppModule {

}
