import { Component, ViewChild, QueryList, ViewChildren } from '@angular/core';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Angular Pipes</h1>
            </div>

            <list [personList]="pList"></list>

            <h2>{{name}}</h2>
            <h2>{{name | uppercase}}</h2>
            <h2>{{name}}</h2>

            <h2>{{today}}</h2>
            <h2>{{today | date}}</h2>
            <h2>{{today | date:'shortTime'}}</h2>
            <h2>{{today | date:'fullDate' | uppercase}}</h2>
            <h2>{{today | date:format}}</h2>

            <button class="btn btn-primary" (click)="updateFlag()">{{flag | caption}}</button>
        <div>
    `
})

export class RootComponent {
    pList: Array<string>;
    name: string;
    today: Date;
    flag: boolean;

    constructor() {
    }

    get format() { return this.flag && 'fullDate' || 'shortDate'; }

    ngOnInit(): void {
        this.name = "manish sharma";
        this.today = new Date();
        this.flag = true;
        this.pList = ["Manish", "Abhijeet", "Kedar", "Avinash", "Mohit", "Ashish", "Ankur", "Kumud"];
    }

    updateFlag() {
        this.flag = !this.flag;
    }
}