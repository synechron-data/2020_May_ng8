import { Component, ViewChild, QueryList, ViewChildren, OnInit } from '@angular/core';
import { Observable, Observer, Subject } from 'rxjs';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Promise & Observable</h1>
            </div>

            <async-promise></async-promise>

            <async-observable></async-observable>
        <div>
    `
})

export class RootComponent implements OnInit {
    observable: Observable<number>;
    subject: Subject<number>;

    constructor() {
    }

    ngOnInit(): void {
        // this.subject = new Subject<number>();

        // setInterval(() => {
        //     this.subject.next(Math.random());
        // }, 2000);

        // this.subject.subscribe(data => {
        //     console.log("Subscriber 1, Output - ", data)
        // });

        // this.subject.subscribe(data => {
        //     console.log("Subscriber 2, Output - ", data)
        // });

        // this.observable = Observable.create((ob: Observer<number>) => {
        //     setInterval(function () {
        //         ob.next(Math.random());
        //     }, 2000);
        // });

        // this.observable.subscribe(data => {
        //     console.log("Subscriber 1, Output - ", data)
        // });

        // this.observable.subscribe(data => {
        //     console.log("Subscriber 2, Output - ", data)
        // });

        // this.getPromise().then((data) => {
        //     console.log("Promise Output - ", data)
        // }, (err) => {
        //     console.log(err);
        // })
    }

    getPromise(): Promise<number> {
        return new Promise((resolve, reject) => {
            setInterval(function () {
                resolve(Math.random());
            }, 2000);
        })
    }
}