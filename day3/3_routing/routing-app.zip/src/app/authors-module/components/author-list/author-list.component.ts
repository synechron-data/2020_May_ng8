import { Component, OnInit } from '@angular/core';
import { AuthorService } from '../../services/author.service';
import { Author } from '../../models/app.author';

@Component({
    selector: 'author-list',
    templateUrl: 'author-list.component.html',
    styleUrls: ['./author-list.component.css']
})

export class AuthorListComponent implements OnInit {
    list: Array<Author>;
    selectedAuthor: Author;
    
    constructor(private aService: AuthorService) { }

    ngOnInit() {
        this.list = this.aService.Authors;
    }

    selectAuthor(a: Author) {
        this.aService.SelectedAuthor = a;
        this.selectedAuthor = this.aService.SelectedAuthor;
    }

    isSelected(a: Author) {
        return this.selectedAuthor === a;
    }

}