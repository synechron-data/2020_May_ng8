import { Component, OnInit } from '@angular/core';
import { DataService } from '../../services/data.service';

@Component({
    selector: 'home',
    templateUrl: 'home.component.html',
    providers: [DataService]
})

export class HomeComponent implements OnInit {
    data: any;
    constructor(private dService: DataService) { }

    ngOnInit() {
        this.dService.getData().subscribe(r => {
            this.data = r.statewise;
        });
    }
}