import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";

import { catchError, retry } from "rxjs/operators";
import { Observable, throwError } from "rxjs";

@Injectable()
export class DataService {
    private url: string;

    constructor(private httpClient: HttpClient) {
        this.url = "https://api.covid19india.org/data.json";
    }

    getData() {
        return this.httpClient.get<Array<any>>(this.url).pipe(
            catchError(this._handleError<any>('getData', []))
        );
    }

    private _handleError<T>(operation = 'operation', result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            console.log(`${operation} failed: ${err.message}`);
            return throwError(err.message);
        }
    }
}